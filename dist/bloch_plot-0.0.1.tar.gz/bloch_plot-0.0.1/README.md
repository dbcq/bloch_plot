# bloch_plot

Simple package for plotting and animations with the Bloch sphere.

## Installation

```
pip install bloch_plot
```
